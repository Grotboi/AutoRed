﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Автосалон</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
<script src="menu.js"></script>
</head>
<body onload="allClose('mainmenu')"> <!-- свернуть пункты меню -->
<div id="mainWrapper">
	<header> <!-- Заголовок -->
		<div id="headerLinks"><a href="#" title="Вход/Регистрация">Вход/Регистрация</a>
							<a href="#" title="Корзина"Корзина></a></div>
	</header>

	<section id="offer">
		<div id="logo"><img src="images/logo.jpeg" alt="пример логотипа" width="100px"></div>
		<!-- в разделе offer отображается текст баннера для рекламных акций -->
		<h2>Лучшие машины только у нас!</h2>
		<p>И мы вам с этим поможем, лучшими услугами и обслуживанием!</p>
</section>
<div>
  <marquee scrollamount="5" scrolldelay="100">
  Добро пожаловать!</marquee>
</div>

	<div id="content">
		<section class="sidebar"> <!--сайдюар с 1 окном поиска, 1 меню-->
			<input type="text" id="search" value="Поиск">
			<div id="menubar">
				<nav class="menu">
				<h2>Навигация </h2><!-- заголовок для меню 1 -->
				<hr>
				<script>
function allClose(){
	var list = document.getElementById("menu").getElementsByTagName("ul");
	for(var i=0;i<list.length;i++){
		list[i].style.display = "none";
	}
}
function openMenu(node){
	var subMenu = node.parentNode.getElementsByTagName("ul")[0];
	subMenu.style.display == "none" ? subMenu.style.display = "block" : subMenu.style.display = "none";
}
</script>
<div>
<ul id="menu">
<li><a href="main.html">Главная</a></1i>
<li><a href="../pages/1.html" onclick="openMenu(this);return false">Авто</a></1i>
<ul>
<li><a href="pages/1.html">Все авто</a></1i>
<li><a href="index3.html">Doom</a></li>
<li><a href="index3.html">Tomb Raider</a></li>
<li><a href="index3.html">Far Cry 3</a></li>
<li><a href="db_material.php">База данных</a></1i>
</ul>
</li>
<li><a href="pages/2.html">О нас</a></1i>
<li><a href="pages/3.html">Контакты</a></1i>
<li><a href="pages/4.html">Галерея</a></1i>
</div>
	</section>
	<div id="db_res"> <!-- Блок сценария -->
<?
function display_form () {
	// Надпись на кнопке отвравки формы по умолчанию
	$submit_msg= "Добавить запись";
?>
	<form method="get" action="<? echo $_SERVER['PHP_SELF'] ?>">
<?
	if ($_REQUEST["id"]) {
	$sql = "SELECT * FROM игры WHERE id=".$_REQUEST["id"];
	$tr = mysql_fetch_array (mysql_query($sql));
?>
	<input type=hidden name="id" value="<? echo $tr["id"] ?>">
<?
	// Надпись на кнопке отправки формы (новая)
	$submit_msg = "Изменить запись";
	} // конец if
?>
<table border=0>
	<tr><td>Название товара:</td>
		<td><input type="text" name="name" size="30" maxlength="30"
			value="<? echo $tr["товар"]; ?>"></td>
	</tr>
	<tr><td>Категория:</td>
		<td><select name="categoria">
			<option <? If ($tr["Категория"]=='Ключ')
				echo 'selected'; ?>>Ключ</option>
			</select>
		</td>
	</tr>
		<tr><td>Описание авто: </td>
			<td><textarea name="description" rows="5" cols="40"
				maxlength="255"><? echo $tr["Описание"] ?></textarea></td>
		</tr>
		<tr><td>Цена: </td>
			<td><input type="number" name="price" min="0" max="9999.99"
				value="<? echo $tr["Цена"]; ?>"></td>
		</tr>
		<tr><td>Количество: </td>
			<td><input type="number" name="qty" min="1" max="65000"
				value="<? echo $tr["Количество"]; ?>"></td>
		</tr>
		<tr><td></td>
			<td><input type="submit" name="submit" value="<? echo $submit_msg; ?>"></td>
		</tr>
		</table>
		</form>
<? } // конец функции display_form() ?>
<?
function change_db() {
/* Функция будет выполнятся, только если все поля формы заполнены или планируется удаление записи*/
	if (($_REQUEST['name'] && $_REQUEST['categoria'] && $_REQUEST['description'] &&
		$_REQUEST['price'] && $_REQUEST['qty']) ||
		($_REQUEST ['submit'] == 'delete')){
	// Введение сокращённых имён для передачи данных
	$name = $_REQUEST['name']; // если планируется удаление, то переменные будут пустыми
	$categoria = $_REQUEST['categoria'];
	$description = $_REQUEST['description'];
	$price = $_REQUEST['price'];
	$qty = $_REQUEST['qty'];

	if (!$_REQUEST["id"]) {
		// id нет только если добавляется новая запись
		$sql = "INSERT INTO игры (товар, Категория, Описание, Цена, Количество)
			VALUES ('$name', '$categoria', '$description', $price, $qty)";
		$info_msg = "Запись добавлена";
	} else if ($_REQUEST["submit"] =='delete') {
		// обработка вызова на удоление
		$sql = "DELETE FROM игры WHERE id=".$_REQUEST['id'];
		$info_msg = "Запись N" . $_REQUEST['id'] . " удолена";
	} else {
		// в остальных случаях подразумевается изменение записи 
		$sql = "UPDATE игры SET товар='$name', Категория='$categoria', Описание='$description', Цена=$price, Количество=$qty
				WHERE id=".$_REQUEST['id'];
		$info_msg = "Запись изменена";
	}
	mysql_query ($sql);
	echo '<p class="info_msg">' .$info_msg . "</p>";
		} // конец первого if
} // конец функции change_db() ?>
<? function print_list() {
	echo "<table id='res'>
			<tr bgcolor=#eeeeee>
			<th>id</th><th>Название товара</th><th>Категория</th><th>Описание</th>
			<th>Цена</th><th>Количество</th>
			<th colspan=2>Редактирование</th></tr>";
	$result = mysql_query("SELECT * FROM игры");
	while ($tr = mysql_fetch_array($result)) {
		
		printf ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td class='td'>%s</td>
				<td class='td'>%s</td>",
				$tr['id'], $tr['товар'], $tr['Категория'], nl2br($tr['Описание']),
				$tr['Цена'], $tr['Количество']);
		printf ("<td><a href=\"%s?id=%s\">(изменить)</a></td>",
			$_SERVER['PHP_SELF'], $tr['id']);
		printf ("<td><a href=\"%s?id=%s&submit=delete\">(удалить)</a></td></tr>",
			$_SERVER['PHP_SELF'], $tr["id"]);
	}
	echo "</table><p></p>";
	echo '<p><a href="' . $_SERVER['PHP _SELF'] . '">Новая запись</a></p>';

} // конец функции print_list()
mysql_select_db("igromir", mysql_connect ('localhost', 'root'));
if ($_REQUEST["submit"]) {change_db();}
print_list();
display_form();
?>
	</div> <!-- Конец блока db_res -->
<footer> <!--Подвал-->
	<div>
		<p>Stroymag &copy; <script>=new Date(); document.write(d.getFullYear()) </script>
		Все права защищены</p>
	</div>
	<div><p></p></div>
	<div>
		<p>За получением дополнительной информации пишите на электронную почту </p>
	</div>
</footer>

</div>
</body>
</html>
