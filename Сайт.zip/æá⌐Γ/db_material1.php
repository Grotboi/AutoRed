﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>База Игры</title>
<link href="css/style1.css" rel="stylesheet" type="text/css">
</head>
<body> <!-- свернуть пункты меню -->

	<div id="db_res"> <!-- Блок сценария -->
<?
function display_form () {
	// Надпись на кнопке отвравки формы по умолчанию
	$submit_msg= "Добавить запись";
?>
	<form method="get" action="<? echo $_SERVER['PHP_SELF'] ?>">
<?
	if ($_REQUEST["id"]) {
	$sql = "SELECT * FROM игры WHERE id=".$_REQUEST["id"];
	$tr = mysql_fetch_array (mysql_query($sql));
?>
	<input type=hidden name="id" value="<? echo $tr["id"] ?>">
<?
	// Надпись на кнопке отправки формы (новая)
	$submit_msg = "Изменить запись";
	} // конец if
?>
<table border=0>
	<tr><td>Название товара:</td>
		<td><input type="text" name="name" size="30" maxlength="30"
			value="<? echo $tr["товар"]; ?>"></td>
	</tr>
	<tr><td>Категория:</td>
		<td><select name="categoria">
			<option <? If ($tr["Категория"]=='Ключ')
				echo 'selected'; ?>>Ключ</option>
			</select>
		</td>
	</tr>
		<tr><td>Описание игры: </td>
			<td><textarea name="description" rows="5" cols="40"
				maxlength="255"><? echo $tr["Описание"] ?></textarea></td>
		</tr>
		<tr><td>Цена: </td>
			<td><input type="number" name="price" min="0" max="9999.99"
				value="<? echo $tr["Цена"]; ?>"></td>
		</tr>
		<tr><td>Количество: </td>
			<td><input type="number" name="qty" min="1" max="65000"
				value="<? echo $tr["Количество"]; ?>"></td>
		</tr>
		<tr><td></td>
			<td><input type="submit" name="submit" value="<? echo $submit_msg; ?>"></td>
		</tr>
		</table>
		</form>
<? } // конец функции display_form() ?>
<?
function change_db() {
/* Функция будет выполнятся, только если все поля формы заполнены или планируется удаление записи*/
	if (($_REQUEST['name'] && $_REQUEST['categoria'] && $_REQUEST['description'] &&
		$_REQUEST['price'] && $_REQUEST['qty']) ||
		($_REQUEST ['submit'] == 'delete')){
	// Введение сокращённых имён для передачи данных
	$name = $_REQUEST['name']; // если планируется удаление, то переменные будут пустыми
	$categoria = $_REQUEST['categoria'];
	$description = $_REQUEST['description'];
	$price = $_REQUEST['price'];
	$qty = $_REQUEST['qty'];

	if (!$_REQUEST["id"]) {
		// id нет только если добавляется новая запись
		$sql = "INSERT INTO игры (товар, Категория, Описание, Цена, Количество)
			VALUES ('$name', '$categoria', '$description', $price, $qty)";
		$info_msg = "Запись добавлена";
	} else if ($_REQUEST["submit"] =='delete') {
		// обработка вызова на удоление
		$sql = "DELETE FROM игры WHERE id=".$_REQUEST['id'];
		$info_msg = "Запись N" . $_REQUEST['id'] . " удолена";
	} else {
		// в остальных случаях подразумевается изменение записи 
		$sql = "UPDATE игры SET товар='$name', Категория='$categoria', Описание='$description', Цена=$price, Количество=$qty
				WHERE id=".$_REQUEST['id'];
		$info_msg = "Запись изменена";
	}
	mysql_query ($sql);
	echo '<p class="info_msg">' .$info_msg . "</p>";
		} // конец первого if
} // конец функции change_db() ?>
<? function print_list() {
	echo "<table id='res'>
			<tr bgcolor=#eeeeee>
			<th>id</th><th>Название товара</th><th>Категория</th><th>Описание</th>
			<th>Цена</th><th>Количество</th>
			<th colspan=2>Редактирование</th></tr>";
	$result = mysql_query("SELECT * FROM игры");
	while ($tr = mysql_fetch_array($result)) {
		
		printf ("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td class='td'>%s</td>
				<td class='td'>%s</td>",
				$tr['id'], $tr['товар'], $tr['Категория'], nl2br($tr['Описание']),
				$tr['Цена'], $tr['Количество']);
		printf ("<td><a href=\"%s?id=%s\"><img alt=' (изменить)' src='images/button1.gif'></a></td>",
			$_SERVER['PHP_SELF'], $tr['id']);
		printf ("<td><a href=\"%s?id=%s&submit=delete\"><img alt='(удалить)'></a></td></tr>",
			$_SERVER['PHP_SELF'], $tr["id"]);
	}
	echo "</table><p></p>";
	echo '<p><a href="' . $_SERVER['PHP _SELF'] . '">Новая запись</a></p>';

} // конец функции print_list()
mysql_select_db("igromir", mysql_connect ('localhost', 'root'));
if ($_REQUEST["submit"]) {change_db();}
print_list();
display_form();
?>
	</div> <!-- Конец блока db_res -->



</body>
</html>
