-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Май 11 2021 г., 08:13
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `Автосалон
--

-- --------------------------------------------------------

--
-- Структура таблицы `Автосалон`
--

CREATE TABLE IF NOT EXISTS `игры` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'первичный ключ',
  `Название товара` varchar(30) NOT NULL COMMENT 'Название товара',
  `Категория` enum('Ключ') NOT NULL COMMENT 'Категория товара',
  `Описание` tinytext CHARACTER SET ucs2 NOT NULL COMMENT 'Описание товара',
  `Цена` float(6,2) unsigned NOT NULL COMMENT 'Цена товара',
  `Количество` int(5) unsigned NOT NULL DEFAULT '1' COMMENT 'Количество товара',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `Автосалон`
--

INSERT INTO `игры` (`id`, `Название товара`, `Категория`, `Описание`, `Цена`, `Количество`) VALUES
(1, 'Doom', 'Ключ', 'Doom (стилизованное написание — DOOM) — мультиплатформенная компьютерная игра в жанре шутера от первого лица. Разработана компа', 1250.00, 22),
(2, 'Tomb Raider', 'Ключ', 'Tomb Raider (с англ. — «Расхитительница гробниц») — кроссплатформенная компьютерная игра в жанре приключенческого боевика от тр', 1879.00, 25),
(3, 'Far Cry 3', 'Ключ', 'Far Cry 3 - это приключенческий шутер от первого лица с открытым миром и элементами RPG, а так же третья (не считая аддонов и с', 560.00, 56),
(4, 'Counter-Strike: Global Offensi', 'Ключ', 'Counter-Strike: Global Offensive (CS:GO; с англ. — «Контрудар: глобальное наступление») — многопользовательская компьютерная иг', 790.00, 54),
(5, 'Overwatch', 'Ключ', 'Сюжет В недалёком будущем между людьми и машинами произошёл глобальный конфликт — восстание омников (игровое название определён', 1460.00, 12),
(6, 'Max Payne', 'Ключ', 'Max Payne — компьютерная игра в жанре шутера от третьего лица, разработанная финской компанией Remedy Entertainment, спродюсиро', 690.00, 5),
(7, 'The Division', 'Ключ', 'The Division — мультиплатформенная компьютерная игра в жанре шутера от третьего лица, первая по счёту из серии игр Tom Clancy''s', 2199.00, 34),
(8, 'Call of Duty', 'Ключ', 'Call of Duty (с англ. — «Зов долга») — компьютерная игра в жанре шутер от первого лица на тему Второй мировой войны, первая игр', 679.00, 23),
(9, 'Star Wars: BattleFront', 'Ключ', 'Star Wars: Battlefront — компьютерная игра в жанре шутер от первого лица (можно переключиться на вид от третьего лица) по вселе', 1990.00, 17);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
